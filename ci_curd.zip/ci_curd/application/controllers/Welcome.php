<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {


	public function index()
	{
		$this->load->model('queries');
		$post =$this->queries->getpost();
		$this->load->view('welcome_message',['posts'=>$post]);
	}
	public function create(){
		
		$this->load->view('create');
	}

	public function update($id){
		
		$this->load->model('queries');
		$post =$this->queries->getsinglepost($id);
		$this->load->view('update',['posts'=>$post]);
	}

	public function save(){
		$this->form_validation->set_rules('title', 'Title', 'required');
		$this->form_validation->set_rules('description', 'Description', 'required');
		if ($this->form_validation->run()){
			$data = $this->input->post();
			$today = date('y-m-d');
			$data['create_at'] = $today;
			unset($data['submit']);
			$this->load->model('queries');
			if($this->queries->save($data)){
					$this->session->set_flashdata('msg','Data insert successfull');
			}else{
				$this->session->set_flashdata('msg','Failed insert data');
			}
			return redirect('welcome');
		}else{
			$this->load->view('create');
		}

		
	}
	public function change($id){
		
		$this->form_validation->set_rules('title', 'Title', 'required');
		$this->form_validation->set_rules('description', 'Description', 'required');
		if ($this->form_validation->run()){
			$data = $this->input->post();
			unset($data['submit']);
			$this->load->model('queries');
			if($this->queries->update($data,$id)){
					$this->session->set_flashdata('msg','Data update successfull');
			}else{
				$this->session->set_flashdata('msg','Failed update data');
			}
			return redirect('welcome');
		}else{
			$this->load->view('create');
		}

	}

	public function view($id){
		$this->load->model('queries');
		$post =$this->queries->getsinglepost($id);
		$this->load->view('view',['post'=>$post]);
	}

	public function delete($id){
		$this->load->model('queries');
		if($this->queries->deletepost($id)){
			$this->session->set_flashdata('msg','Data delete successfull');
		}else{
			$this->session->set_flashdata('msg','delete Failed');
		}
		return redirect('welcome');
	}
}
