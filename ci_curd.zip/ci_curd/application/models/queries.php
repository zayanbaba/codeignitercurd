<?php 
class Queries extends CI_Model{
    public function getpost(){
        $query = $this->db->get('tbli_blogs');
        if($query->num_rows()>0){
            return $query->result();
        }
    }
    public function save($data){
     return $this->db->insert('tbli_blogs', $data);
    }
    public function getsinglepost($id){
      $query = $this->db->get_where('tbli_blogs', array('id' => $id));
        if($query->num_rows()>0){
            return $query->row();
        }
    }
    public function update($data,$id){
     return $this->db->where('id',$id)
                   ->update('tbli_blogs',$data); 
    }
    public function deletepost($id){
        return $this->db->delete('tbli_blogs',['id'=>$id]);
    }
} 
?>