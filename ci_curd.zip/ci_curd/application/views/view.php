<?php include_once('header.php');?>
<div class="container">
    <h4>View Posts</h4>
    <h5><?php echo $post->title?></h5>
    <p><?php echo $post->description?></p>
    <h6><?php echo $post->create_at?></h6>
</div>