<?php include_once('header.php');?>
<div class ="container">
	<h3>View All Post</h3>
	<?php if($msg = $this->session->flashdata('msg')):?>
	<?php echo $msg;?>
    <?php endif;?>
	<?php echo anchor('welcome/create','ADD POST',['class'=>'btn btn-primary'])?>
	<br><br>
	<table class="table table-hover">
		<thead>
			<tr>
			<th scope="col">Title</th>
			<th scope="col">Description</th>
			<th scope="col">Create Date</th>
			<th scope="col">Action</th>
			</tr>
		</thead>
		<tbody>
			<?php if(count($posts)):?>
				<?php foreach($posts as $post):?>
			<tr class="table-active">
			<th><?php echo $post->title?></th>
			<td><?php echo $post->description?></td>
			<td><?php echo $post->create_at?></td>
			<td>
			<?php echo anchor("welcome/View/{$post->id}",'View',['class'=>'btn btn-info'])?>
			<?php echo anchor("welcome/Update/{$post->id}",'Update',['class'=>'btn btn-success'])?>
			<?php echo anchor("welcome/Delete/{$post->id}",'Delete',['class'=>'btn btn-danger'])?>
			</td>
			</tr>
			<?php endforeach;?>
			<?php else:?>
			<tr>
				<td>
					NO Record found!!!
				</td>
			</tr>
			<?php endif;?>
		</tbody>
    </table> 
</div>
	<?php include_once('footer.php');?>